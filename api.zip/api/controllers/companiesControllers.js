exports.getCompanies = async (req, res) => {
  res.send("Get all companies");
};

exports.getCompany = async (req, res) => {
  const companyId = req.params.id;
  res.send("Hello, company #" + companyId);
};

exports.createCompany = async (req, res) => {
  res.send("Company created");
};

exports.updateCompany = async (req, res) => {
  res.send("Company updated");
};

exports.deleteCompany = async (req, res) => {
  res.send("Company deleted");
};
