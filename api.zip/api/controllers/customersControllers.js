exports.getCustomers = async (req, res) => {
  res.send("Get all customers");
};

exports.getCustomer = async (req, res) => {
  const customerId = req.params.id;
  res.send("Hello, customer #" + customerId);
};

exports.createCustomer = async (req, res) => {
  res.send("Customer created");
};

exports.updateCustomer = async (req, res) => {
  res.send("Customer updated");
};

exports.deleteCustomer = async (req, res) => {
  res.send("Customer deleted");
};
