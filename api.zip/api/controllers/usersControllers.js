const prisma = require("../utils/prismaClient");

exports.getUsers = async (req, res) => {
  const users = await prisma.user.findMany();

  res.json({
    users,
  });
};

exports.getUser = async (req, res) => {
  const userId = req.params.id;
  res.send("Hello, user #" + userId);
};

exports.createUser = async (req, res) => {
  res.send("User created");
};

exports.updateUser = async (req, res) => {
  res.send("User updated");
};

exports.deleteUser = async (req, res) => {
  res.send("User deleted");
};
