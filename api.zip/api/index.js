const express = require("express");
const bodyParser = require("body-parser");

// Routes
const usersRoutes = require("./routes/usersRoutes");
const companiesRoutes = require("./routes/companiesRoutes");
const customersRoutes = require("./routes/customersRoutes");

const app = express();
const port = 3000;

app.use(bodyParser.json());

app.get("/", (req, res) => {
  res.send("Welcome to CRM API");
});

app.use("/users", usersRoutes);
app.use("/companies", companiesRoutes);
app.use("/customers", customersRoutes);

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`);
});
