const express = require("express");

const router = express.Router();

const companiesControllers = require("../controllers/companiesControllers");

router.get("/", companiesControllers.getCompanies);
router.post("/", companiesControllers.createCompany);
router.get("/:id", companiesControllers.getCompany);
router.patch("/:id", companiesControllers.updateCompany);
router.delete("/:id", companiesControllers.deleteCompany);

module.exports = router;
