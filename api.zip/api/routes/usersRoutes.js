const express = require("express");

const router = express.Router();

const usersControllers = require("../controllers/usersControllers");

router.get("/", usersControllers.getUsers);
router.post("/", usersControllers.createUser);
router.get("/:id", usersControllers.getUser);
router.patch("/:id", usersControllers.updateUser);
router.delete("/:id", usersControllers.deleteUser);

module.exports = router;
