const express = require("express");

const router = express.Router();

const customersControllers = require("../controllers/customersControllers");

router.get("/", customersControllers.getCustomers);
router.post("/", customersControllers.createCustomer);
router.get("/:id", customersControllers.getCustomer);
router.patch("/:id", customersControllers.updateCustomer);
router.delete("/:id", customersControllers.deleteCustomer);

module.exports = router;
